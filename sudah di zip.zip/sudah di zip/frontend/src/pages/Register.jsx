import { Link } from "react-router-dom";

export default function Register() {
  return (
    <main className="form-signin w-100 m-auto">
      <form>
        <img className="mb-4" src="../assets/brand/bootstrap-logo.svg" alt width={72} height={57} />
        <h1 className="h3 mb-3 fw-normal">Form Register</h1>
        <div className="form-floating">
          <input type="text" className="form-control" id="floatingInput" placeholder="Masukkan Nama" />
          <label htmlFor="floatingInput">Nama Pengguna</label>
        </div>
        <div className="form-floating">
          <input type="email" className="form-control" id="floatingInput" placeholder="name@example.com" />
          <label htmlFor="floatingInput">Alamat Email</label>
        </div>
        <div className="form-floating">
          <input type="password" className="form-control" id="floatingPassword" placeholder="Password" />
          <label htmlFor="floatingPassword">Password</label>
        </div>
     <div className="form-floating">
          <input type="number" className="form-control" id="floatingInput" placeholder="Masukkan Nomor HP" />
          <label htmlFor="floatingInput">Nomor HP</label>
        </div>
        <button className="btn btn-primary w-100 py-2" type="submit">
          Register
        </button>
        <Link to={'/login'} className="btn btn-secondary w-100 py-2" type="submit">Login</Link>
        <p className="mt-5 mb-3 text-body-secondary">© 2017–2025</p>
      </form>
    </main>

  )
}